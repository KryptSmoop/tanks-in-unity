﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gun : MonoBehaviour
{
	// Start is called before the first frame update

	float zRot;

	public GameObject bullet;

	Vector2 pos;

	Vector2 dir;

	Bullet b;

	void Start()
	{
		b = bullet.GetComponent<Bullet>();
	}

	// Update is called once per frame
	void Update()
    {
		pos = transform.position;

		dir = (Vector2) Input.mousePosition - pos;

		zRot = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;

		transform.rotation = Quaternion.AngleAxis(zRot, Vector3.forward);


		if (Input.GetButtonDown("Jump"))
		{
			//print(zRot);
			b.setRot(zRot);
			Instantiate(bullet);
		}
    }
}
