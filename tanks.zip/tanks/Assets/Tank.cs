﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tank : MonoBehaviour
{
    // Start is called before the first frame update

    float xCon, yCon;

    public float turnVel, vel;

    Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        xCon = Input.GetAxis("Horizontal");
        yCon = Input.GetAxis("Vertical");
        Turn();
        Move();
    }

    void Turn()
    {
        float turn = xCon * turnVel * Time.deltaTime;

        Quaternion turnRot = Quaternion.Euler(0f, 0f, turn);

        rb.MoveRotation(rb.rotation * turnRot);  
    }

    void Move()
    {
        Vector3 movement = transform.up * yCon * vel * Time.deltaTime;

        rb.MovePosition(rb.position + movement);
    }
}
